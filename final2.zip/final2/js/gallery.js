$(document).ready(function() {
	$(window).on("scroll", function() {
		var position = $("#begin").offset();

		if($(window).scrollTop() > position.top - 80) {
			// do something when active state touches the 
			// nav
			$("nav").addClass("active");
		} else {
			$("nav").removeClass("active");
		}


	})
})

$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    
    });
});

$(document).ready(function(){
    $("#flip").hover(function(){
        $(this).css("background-color", "yellow");
        }, function(){
        $(this).css("background-color", "lightBlue");
    });
});
